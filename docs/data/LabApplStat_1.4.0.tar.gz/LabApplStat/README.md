# LabApplStat
R package with miscellaneous scripts developed at the Data Science Laboratory, University of Copenhagen.
